# 📁 Images Directory

## 🎯 **REQUIRED IMAGES:**

### **1. tekup.png**
- **Description**: TEK-UP school logo
- **Usage**: Cover page (left side)
- **Size**: Recommended 200x200px or similar

### **2. bvmt logo.png**
- **Description**: Bourse de Tunis (BVMT) logo
- **Usage**: Cover page (right side)
- **Size**: Recommended 200x200px or similar

### **3. technologies_tools.png**
- **Description**: Technologies and tools used in the project
- **Usage**: Requirements section (section 3)
- **Size**: Recommended 800x600px or similar
- **Content**: Should show Python, React, Flask, PostgreSQL, Docker, etc.

### **4. medallion_architecture.png**
- **Description**: Medallion architecture diagram showing the 4 layers
- **Usage**: Architecture section (section 4)
- **Size**: Recommended 800x600px or similar
- **Content**: Bronze, Silver, Golden, Diamond layers with data flow

### **5. scraping_process.png**
- **Description**: Automated scraping process from BVMT
- **Usage**: Scraping section (section 5)
- **Size**: Recommended 800x600px or similar
- **Content**: Data collection flow, file formats, validation process

### **6. web_platform_interface.png**
- **Description**: Main web platform interface
- **Usage**: Web Platform section (section 8)
- **Size**: Recommended 800x600px or similar
- **Content**: React interface, dashboard, navigation

### **7. financial_models.png**
- **Description**: Financial analysis models and predictions
- **Usage**: Financial Analysis section (section 7)
- **Size**: Recommended 800x600px or similar
- **Content**: LSTM, GARCH, VAR models, statistical tests

### **8. powerbi_intro.png**
- **Description**: PowerBI introduction and architecture
- **Usage**: PowerBI section (section 8)
- **Size**: Recommended 800x600px or similar
- **Content**: PowerBI architecture overview

### **9. powerbi_connection.png**
- **Description**: PowerBI data connection to PostgreSQL
- **Usage**: PowerBI section (section 8)
- **Size**: Recommended 800x600px or similar
- **Content**: Database connection diagram

### **10. powerbi_model.png**
- **Description**: PowerBI data model
- **Usage**: PowerBI section (section 8)
- **Size**: Recommended 800x600px or similar
- **Content**: Data model relationships

### **11. powerbi_ml_dashboard.png**
- **Description**: PowerBI ML dashboard
- **Usage**: PowerBI section (section 8)
- **Size**: Recommended 800x600px or similar
- **Content**: Machine learning predictions dashboard

### **12. powerbi_statistical_dashboard.png**
- **Description**: PowerBI statistical validation dashboard
- **Usage**: PowerBI section (section 8)
- **Size**: Recommended 800x600px or similar
- **Content**: Statistical test results

### **13. powerbi_garch_dashboard.png**
- **Description**: PowerBI GARCH volatility dashboard
- **Usage**: PowerBI section (section 8)
- **Size**: Recommended 800x600px or similar
- **Content**: GARCH volatility analysis

### **14. powerbi_technical_dashboard.png**
- **Description**: PowerBI technical signals dashboard
- **Usage**: PowerBI section (section 8)
- **Size**: Recommended 800x600px or similar
- **Content**: Technical analysis and trading signals

### **15. powerbi_strategy_dashboard.png**
- **Description**: PowerBI strategy and relationships dashboard
- **Usage**: PowerBI section (section 8)
- **Size**: Recommended 800x600px or similar
- **Content**: Investment strategies and correlations

### **16. powerbi_web_integration.png**
- **Description**: PowerBI web integration
- **Usage**: PowerBI section (section 8)
- **Size**: Recommended 800x600px or similar
- **Content**: Web platform integration

### **17. powerbi_performance.png**
- **Description**: PowerBI performance optimization
- **Usage**: PowerBI section (section 8)
- **Size**: Recommended 800x600px or similar
- **Content**: Performance metrics and optimization

### **18. testing_intro.png**
- **Description**: Testing and validation introduction
- **Usage**: Testing section (section 9)
- **Size**: Recommended 800x600px or similar
- **Content**: Testing strategy overview

### **19. testing_ai_bot.png**
- **Description**: AI Bot API testing
- **Usage**: Testing section (section 9)
- **Size**: Recommended 800x600px or similar
- **Content**: AI Bot test results

### **20. testing_etl_apis.png**
- **Description**: ETL pipeline API testing
- **Usage**: Testing section (section 9)
- **Size**: Recommended 800x600px or similar
- **Content**: ETL API test results

### **21. testing_auth_api.png**
- **Description**: Authentication API testing
- **Usage**: Testing section (section 9)
- **Size**: Recommended 800x600px or similar
- **Content**: Authentication test results

### **22. testing_load.png**
- **Description**: Load and performance testing
- **Usage**: Testing section (section 9)
- **Size**: Recommended 800x600px or similar
- **Content**: Load test results

### **23. testing_stability.png**
- **Description**: System stability testing
- **Usage**: Testing section (section 9)
- **Size**: Recommended 800x600px or similar
- **Content**: Stability test results

### **24. testing_e2e.png**
- **Description**: End-to-end testing
- **Usage**: Testing section (section 9)
- **Size**: Recommended 800x600px or similar
- **Content**: E2E test results

### **25. testing_regression.png**
- **Description**: Regression testing
- **Usage**: Testing section (section 9)
- **Size**: Recommended 800x600px or similar
- **Content**: Regression test results

### **26. testing_automation.png**
- **Description**: Test automation
- **Usage**: Testing section (section 9)
- **Size**: Recommended 800x600px or similar
- **Content**: Automated test framework

### **27. testing_monitoring.png**
- **Description**: Test monitoring and alerts
- **Usage**: Testing section (section 9)
- **Size**: Recommended 800x600px or similar
- **Content**: Test monitoring dashboard

## 📝 **INSTRUCTIONS:**

1. **Place your images** in this `img/` directory
2. **Use PNG format** for best quality
3. **Ensure proper naming** as specified above
4. **Test compilation** in Overleaf after adding images
5. **All images use width = 0.5** (consistent sizing)

## 🎨 **SUGGESTED CONTENT FOR EACH IMAGE:**

### **technologies_tools.png:**
- Python logo
- React logo
- Flask logo
- PostgreSQL logo
- Docker logo
- Git logo
- PowerBI logo
- JWT/Authentication icons
- Machine Learning icons (TensorFlow, scikit-learn)
- Data visualization icons

### **medallion_architecture.png:**
- 4-layer diagram (Bronze → Silver → Golden → Diamond)
- Data flow arrows
- Processing steps
- Storage formats
- Technology stack per layer

### **scraping_process.png:**
- BVMT website connection
- File download process
- Format handling (ZIP, RAR, CSV)
- Data validation steps
- Error handling

### **web_platform_interface.png:**
- React dashboard
- Navigation menu
- Data visualization panels
- AI chatbot interface
- User authentication

### **financial_models.png:**
- LSTM neural network diagram
- GARCH model structure
- Statistical test results
- Prediction accuracy metrics
- Risk analysis charts

## ✅ **READY TO USE:**

Once you add these images, your LaTeX report will compile perfectly with:
- ✅ Professional cover page
- ✅ List of figures (automatic)
- ✅ List of tables (automatic)
- ✅ Consistent image sizing (width = 0.5)
- ✅ All sections with visual content
